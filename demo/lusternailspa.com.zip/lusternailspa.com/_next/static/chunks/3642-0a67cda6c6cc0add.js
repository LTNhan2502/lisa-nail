"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [3642], {
        34017: (t, e, s) => {
            s.d(e, {
                m: () => n
            });
            var r = s(99323),
                i = s(84403),
                n = new class extends r.Q {#
                    t;#
                    e;#
                    s;
                    constructor() {
                        super(), this.#s = t => {
                            if (!i.S$ && window.addEventListener) {
                                let e = () => t();
                                return window.addEventListener("visibilitychange", e, !1), () => {
                                    window.removeEventListener("visibilitychange", e)
                                }
                            }
                        }
                    }
                    onSubscribe() {
                        this.#e || this.setEventListener(this.#s)
                    }
                    onUnsubscribe() {
                        this.hasListeners() || (this.#e ? .(), this.#e = void 0)
                    }
                    setEventListener(t) {
                        this.#s = t, this.#e ? .(), this.#e = t(t => {
                            "boolean" == typeof t ? this.setFocused(t) : this.onFocus()
                        })
                    }
                    setFocused(t) {
                        this.#t !== t && (this.#t = t, this.onFocus())
                    }
                    onFocus() {
                        let t = this.isFocused();
                        this.listeners.forEach(e => {
                            e(t)
                        })
                    }
                    isFocused() {
                        return "boolean" == typeof this.#t ? this.#t : globalThis.document ? .visibilityState !== "hidden"
                    }
                }
        },
        15586: (t, e, s) => {
            s.d(e, {
                jG: () => i
            });
            var r = t => setTimeout(t, 0),
                i = function() {
                    let t = [],
                        e = 0,
                        s = t => {
                            t()
                        },
                        i = t => {
                            t()
                        },
                        n = r,
                        a = r => {
                            e ? t.push(r) : n(() => {
                                s(r)
                            })
                        },
                        u = () => {
                            let e = t;
                            t = [], e.length && n(() => {
                                i(() => {
                                    e.forEach(t => {
                                        s(t)
                                    })
                                })
                            })
                        };
                    return {
                        batch: t => {
                            let s;
                            e++;
                            try {
                                s = t()
                            } finally {
                                --e || u()
                            }
                            return s
                        },
                        batchCalls: t => (...e) => {
                            a(() => {
                                t(...e)
                            })
                        },
                        schedule: a,
                        setNotifyFunction: t => {
                            s = t
                        },
                        setBatchNotifyFunction: t => {
                            i = t
                        },
                        setScheduler: t => {
                            n = t
                        }
                    }
                }()
        },
        38248: (t, e, s) => {
            s.d(e, {
                t: () => n
            });
            var r = s(99323),
                i = s(84403),
                n = new class extends r.Q {#
                    r = !0;#
                    e;#
                    s;
                    constructor() {
                        super(), this.#s = t => {
                            if (!i.S$ && window.addEventListener) {
                                let e = () => t(!0),
                                    s = () => t(!1);
                                return window.addEventListener("online", e, !1), window.addEventListener("offline", s, !1), () => {
                                    window.removeEventListener("online", e), window.removeEventListener("offline", s)
                                }
                            }
                        }
                    }
                    onSubscribe() {
                        this.#e || this.setEventListener(this.#s)
                    }
                    onUnsubscribe() {
                        this.hasListeners() || (this.#e ? .(), this.#e = void 0)
                    }
                    setEventListener(t) {
                        this.#s = t, this.#e ? .(), this.#e = t(this.setOnline.bind(this))
                    }
                    setOnline(t) {
                        this.#r !== t && (this.#r = t, this.listeners.forEach(e => {
                            e(t)
                        }))
                    }
                    isOnline() {
                        return this.#r
                    }
                }
        },
        47702: (t, e, s) => {
            s.d(e, {
                X: () => u,
                k: () => o
            });
            var r = s(84403),
                i = s(15586),
                n = s(14267),
                a = s(2955),
                u = class extends a.k {#
                    i;#
                    n;#
                    a;#
                    u;#
                    o;#
                    h;#
                    c;
                    constructor(t) {
                        super(), this.#c = !1, this.#h = t.defaultOptions, this.setOptions(t.options), this.observers = [], this.#u = t.client, this.#a = this.#u.getQueryCache(), this.queryKey = t.queryKey, this.queryHash = t.queryHash, this.#i = function(t) {
                            let e = "function" == typeof t.initialData ? t.initialData() : t.initialData,
                                s = void 0 !== e,
                                r = s ? "function" == typeof t.initialDataUpdatedAt ? t.initialDataUpdatedAt() : t.initialDataUpdatedAt : 0;
                            return {
                                data: e,
                                dataUpdateCount: 0,
                                dataUpdatedAt: s ? r ? ? Date.now() : 0,
                                error: null,
                                errorUpdateCount: 0,
                                errorUpdatedAt: 0,
                                fetchFailureCount: 0,
                                fetchFailureReason: null,
                                fetchMeta: null,
                                isInvalidated: !1,
                                status: s ? "success" : "pending",
                                fetchStatus: "idle"
                            }
                        }(this.options), this.state = t.state ? ? this.#i, this.scheduleGc()
                    }
                    get meta() {
                        return this.options.meta
                    }
                    get promise() {
                        return this.#o ? .promise
                    }
                    setOptions(t) {
                        this.options = { ...this.#h,
                            ...t
                        }, this.updateGcTime(this.options.gcTime)
                    }
                    optionalRemove() {
                        this.observers.length || "idle" !== this.state.fetchStatus || this.#a.remove(this)
                    }
                    setData(t, e) {
                        let s = (0, r.pl)(this.state.data, t, this.options);
                        return this.#l({
                            data: s,
                            type: "success",
                            dataUpdatedAt: e ? .updatedAt,
                            manual: e ? .manual
                        }), s
                    }
                    setState(t, e) {
                        this.#l({
                            type: "setState",
                            state: t,
                            setStateOptions: e
                        })
                    }
                    cancel(t) {
                        let e = this.#o ? .promise;
                        return this.#o ? .cancel(t), e ? e.then(r.lQ).catch(r.lQ) : Promise.resolve()
                    }
                    destroy() {
                        super.destroy(), this.cancel({
                            silent: !0
                        })
                    }
                    reset() {
                        this.destroy(), this.setState(this.#i)
                    }
                    isActive() {
                        return this.observers.some(t => !1 !== (0, r.Eh)(t.options.enabled, this))
                    }
                    isDisabled() {
                        return this.getObserversCount() > 0 ? !this.isActive() : this.options.queryFn === r.hT || this.state.dataUpdateCount + this.state.errorUpdateCount === 0
                    }
                    isStale() {
                        return !!this.state.isInvalidated || (this.getObserversCount() > 0 ? this.observers.some(t => t.getCurrentResult().isStale) : void 0 === this.state.data)
                    }
                    isStaleByTime(t = 0) {
                        return this.state.isInvalidated || void 0 === this.state.data || !(0, r.j3)(this.state.dataUpdatedAt, t)
                    }
                    onFocus() {
                        let t = this.observers.find(t => t.shouldFetchOnWindowFocus());
                        t ? .refetch({
                            cancelRefetch: !1
                        }), this.#o ? .continue()
                    }
                    onOnline() {
                        let t = this.observers.find(t => t.shouldFetchOnReconnect());
                        t ? .refetch({
                            cancelRefetch: !1
                        }), this.#o ? .continue()
                    }
                    addObserver(t) {
                        this.observers.includes(t) || (this.observers.push(t), this.clearGcTimeout(), this.#a.notify({
                            type: "observerAdded",
                            query: this,
                            observer: t
                        }))
                    }
                    removeObserver(t) {
                        this.observers.includes(t) && (this.observers = this.observers.filter(e => e !== t), this.observers.length || (this.#o && (this.#c ? this.#o.cancel({
                            revert: !0
                        }) : this.#o.cancelRetry()), this.scheduleGc()), this.#a.notify({
                            type: "observerRemoved",
                            query: this,
                            observer: t
                        }))
                    }
                    getObserversCount() {
                        return this.observers.length
                    }
                    invalidate() {
                        this.state.isInvalidated || this.#l({
                            type: "invalidate"
                        })
                    }
                    fetch(t, e) {
                        if ("idle" !== this.state.fetchStatus) {
                            if (void 0 !== this.state.data && e ? .cancelRefetch) this.cancel({
                                silent: !0
                            });
                            else if (this.#o) return this.#o.continueRetry(), this.#o.promise
                        }
                        if (t && this.setOptions(t), !this.options.queryFn) {
                            let t = this.observers.find(t => t.options.queryFn);
                            t && this.setOptions(t.options)
                        }
                        let s = new AbortController,
                            i = t => {
                                Object.defineProperty(t, "signal", {
                                    enumerable: !0,
                                    get: () => (this.#c = !0, s.signal)
                                })
                            },
                            a = {
                                fetchOptions: e,
                                options: this.options,
                                queryKey: this.queryKey,
                                client: this.#u,
                                state: this.state,
                                fetchFn: () => {
                                    let t = (0, r.ZM)(this.options, e),
                                        s = {
                                            client: this.#u,
                                            queryKey: this.queryKey,
                                            meta: this.meta
                                        };
                                    return (i(s), this.#c = !1, this.options.persister) ? this.options.persister(t, s, this) : t(s)
                                }
                            };
                        i(a), this.options.behavior ? .onFetch(a, this), this.#n = this.state, ("idle" === this.state.fetchStatus || this.state.fetchMeta !== a.fetchOptions ? .meta) && this.#l({
                            type: "fetch",
                            meta: a.fetchOptions ? .meta
                        });
                        let u = t => {
                            (0, n.wm)(t) && t.silent || this.#l({
                                type: "error",
                                error: t
                            }), (0, n.wm)(t) || (this.#a.config.onError ? .(t, this), this.#a.config.onSettled ? .(this.state.data, t, this)), this.scheduleGc()
                        };
                        return this.#o = (0, n.II)({
                            initialPromise: e ? .initialPromise,
                            fn: a.fetchFn,
                            abort: s.abort.bind(s),
                            onSuccess: t => {
                                if (void 0 === t) {
                                    u(Error(`${this.queryHash} data is undefined`));
                                    return
                                }
                                try {
                                    this.setData(t)
                                } catch (t) {
                                    u(t);
                                    return
                                }
                                this.#a.config.onSuccess ? .(t, this), this.#a.config.onSettled ? .(t, this.state.error, this), this.scheduleGc()
                            },
                            onError: u,
                            onFail: (t, e) => {
                                this.#l({
                                    type: "failed",
                                    failureCount: t,
                                    error: e
                                })
                            },
                            onPause: () => {
                                this.#l({
                                    type: "pause"
                                })
                            },
                            onContinue: () => {
                                this.#l({
                                    type: "continue"
                                })
                            },
                            retry: a.options.retry,
                            retryDelay: a.options.retryDelay,
                            networkMode: a.options.networkMode,
                            canRun: () => !0
                        }), this.#o.start()
                    }#
                    l(t) {
                        this.state = (e => {
                            switch (t.type) {
                                case "failed":
                                    return { ...e,
                                        fetchFailureCount: t.failureCount,
                                        fetchFailureReason: t.error
                                    };
                                case "pause":
                                    return { ...e,
                                        fetchStatus: "paused"
                                    };
                                case "continue":
                                    return { ...e,
                                        fetchStatus: "fetching"
                                    };
                                case "fetch":
                                    return { ...e,
                                        ...o(e.data, this.options),
                                        fetchMeta: t.meta ? ? null
                                    };
                                case "success":
                                    return { ...e,
                                        data: t.data,
                                        dataUpdateCount: e.dataUpdateCount + 1,
                                        dataUpdatedAt: t.dataUpdatedAt ? ? Date.now(),
                                        error: null,
                                        isInvalidated: !1,
                                        status: "success",
                                        ...!t.manual && {
                                            fetchStatus: "idle",
                                            fetchFailureCount: 0,
                                            fetchFailureReason: null
                                        }
                                    };
                                case "error":
                                    let s = t.error;
                                    if ((0, n.wm)(s) && s.revert && this.#n) return { ...this.#n,
                                        fetchStatus: "idle"
                                    };
                                    return { ...e,
                                        error: s,
                                        errorUpdateCount: e.errorUpdateCount + 1,
                                        errorUpdatedAt: Date.now(),
                                        fetchFailureCount: e.fetchFailureCount + 1,
                                        fetchFailureReason: s,
                                        fetchStatus: "idle",
                                        status: "error"
                                    };
                                case "invalidate":
                                    return { ...e,
                                        isInvalidated: !0
                                    };
                                case "setState":
                                    return { ...e,
                                        ...t.state
                                    }
                            }
                        })(this.state), i.jG.batch(() => {
                            this.observers.forEach(t => {
                                t.onQueryUpdate()
                            }), this.#a.notify({
                                query: this,
                                type: "updated",
                                action: t
                            })
                        })
                    }
                };

            function o(t, e) {
                return {
                    fetchFailureCount: 0,
                    fetchFailureReason: null,
                    fetchStatus: (0, n.v_)(e.networkMode) ? "fetching" : "paused",
                    ...void 0 === t && {
                        error: null,
                        status: "pending"
                    }
                }
            }
        },
        24724: (t, e, s) => {
            s.d(e, {
                $: () => h
            });
            var r = s(34017),
                i = s(15586),
                n = s(47702),
                a = s(99323),
                u = s(41277),
                o = s(84403),
                h = class extends a.Q {
                    constructor(t, e) {
                        super(), this.options = e, this.#u = t, this.#d = null, this.#f = (0, u.T)(), this.options.experimental_prefetchInRender || this.#f.reject(Error("experimental_prefetchInRender feature flag is not enabled")), this.bindMethods(), this.setOptions(e)
                    }#
                    u;#
                    p = void 0;#
                    y = void 0;#
                    v = void 0;#
                    b;#
                    m;#
                    f;#
                    d;#
                    R;#
                    g;#
                    S;#
                    O;#
                    Q;#
                    C;#
                    E = new Set;
                    bindMethods() {
                        this.refetch = this.refetch.bind(this)
                    }
                    onSubscribe() {
                        1 === this.listeners.size && (this.#p.addObserver(this), c(this.#p, this.options) ? this.#w() : this.updateResult(), this.#T())
                    }
                    onUnsubscribe() {
                        this.hasListeners() || this.destroy()
                    }
                    shouldFetchOnReconnect() {
                        return l(this.#p, this.options, this.options.refetchOnReconnect)
                    }
                    shouldFetchOnWindowFocus() {
                        return l(this.#p, this.options, this.options.refetchOnWindowFocus)
                    }
                    destroy() {
                        this.listeners = new Set, this.#F(), this.#I(), this.#p.removeObserver(this)
                    }
                    setOptions(t) {
                        let e = this.options,
                            s = this.#p;
                        if (this.options = this.#u.defaultQueryOptions(t), void 0 !== this.options.enabled && "boolean" != typeof this.options.enabled && "function" != typeof this.options.enabled && "boolean" != typeof(0, o.Eh)(this.options.enabled, this.#p)) throw Error("Expected enabled to be a boolean or a callback that returns a boolean");
                        this.#j(), this.#p.setOptions(this.options), e._defaulted && !(0, o.f8)(this.options, e) && this.#u.getQueryCache().notify({
                            type: "observerOptionsUpdated",
                            query: this.#p,
                            observer: this
                        });
                        let r = this.hasListeners();
                        r && d(this.#p, s, this.options, e) && this.#w(), this.updateResult(), r && (this.#p !== s || (0, o.Eh)(this.options.enabled, this.#p) !== (0, o.Eh)(e.enabled, this.#p) || (0, o.d2)(this.options.staleTime, this.#p) !== (0, o.d2)(e.staleTime, this.#p)) && this.#U();
                        let i = this.#k();
                        r && (this.#p !== s || (0, o.Eh)(this.options.enabled, this.#p) !== (0, o.Eh)(e.enabled, this.#p) || i !== this.#C) && this.#D(i)
                    }
                    getOptimisticResult(t) {
                        let e = this.#u.getQueryCache().build(this.#u, t),
                            s = this.createResult(e, t);
                        return (0, o.f8)(this.getCurrentResult(), s) || (this.#v = s, this.#m = this.options, this.#b = this.#p.state), s
                    }
                    getCurrentResult() {
                        return this.#v
                    }
                    trackResult(t, e) {
                        let s = {};
                        return Object.keys(t).forEach(r => {
                            Object.defineProperty(s, r, {
                                configurable: !1,
                                enumerable: !0,
                                get: () => (this.trackProp(r), e ? .(r), t[r])
                            })
                        }), s
                    }
                    trackProp(t) {
                        this.#E.add(t)
                    }
                    getCurrentQuery() {
                        return this.#p
                    }
                    refetch({ ...t
                    } = {}) {
                        return this.fetch({ ...t
                        })
                    }
                    fetchOptimistic(t) {
                        let e = this.#u.defaultQueryOptions(t),
                            s = this.#u.getQueryCache().build(this.#u, e);
                        return s.fetch().then(() => this.createResult(s, e))
                    }
                    fetch(t) {
                        return this.#w({ ...t,
                            cancelRefetch: t.cancelRefetch ? ? !0
                        }).then(() => (this.updateResult(), this.#v))
                    }#
                    w(t) {
                        this.#j();
                        let e = this.#p.fetch(this.options, t);
                        return t ? .throwOnError || (e = e.catch(o.lQ)), e
                    }#
                    U() {
                        this.#F();
                        let t = (0, o.d2)(this.options.staleTime, this.#p);
                        if (o.S$ || this.#v.isStale || !(0, o.gn)(t)) return;
                        let e = (0, o.j3)(this.#v.dataUpdatedAt, t);
                        this.#O = setTimeout(() => {
                            this.#v.isStale || this.updateResult()
                        }, e + 1)
                    }#
                    k() {
                        return ("function" == typeof this.options.refetchInterval ? this.options.refetchInterval(this.#p) : this.options.refetchInterval) ? ? !1
                    }#
                    D(t) {
                        this.#I(), this.#C = t, !o.S$ && !1 !== (0, o.Eh)(this.options.enabled, this.#p) && (0, o.gn)(this.#C) && 0 !== this.#C && (this.#Q = setInterval(() => {
                            (this.options.refetchIntervalInBackground || r.m.isFocused()) && this.#w()
                        }, this.#C))
                    }#
                    T() {
                        this.#U(), this.#D(this.#k())
                    }#
                    F() {
                        this.#O && (clearTimeout(this.#O), this.#O = void 0)
                    }#
                    I() {
                        this.#Q && (clearInterval(this.#Q), this.#Q = void 0)
                    }
                    createResult(t, e) {
                        let s;
                        let r = this.#p,
                            i = this.options,
                            a = this.#v,
                            h = this.#b,
                            l = this.#m,
                            p = t !== r ? t.state : this.#y,
                            {
                                state: y
                            } = t,
                            v = { ...y
                            },
                            b = !1;
                        if (e._optimisticResults) {
                            let s = this.hasListeners(),
                                a = !s && c(t, e),
                                u = s && d(t, r, e, i);
                            (a || u) && (v = { ...v,
                                ...(0, n.k)(y.data, t.options)
                            }), "isRestoring" === e._optimisticResults && (v.fetchStatus = "idle")
                        }
                        let {
                            error: m,
                            errorUpdatedAt: R,
                            status: g
                        } = v;
                        if (e.select && void 0 !== v.data) {
                            if (a && v.data === h ? .data && e.select === this.#R) s = this.#g;
                            else try {
                                this.#R = e.select, s = e.select(v.data), s = (0, o.pl)(a ? .data, s, e), this.#g = s, this.#d = null
                            } catch (t) {
                                this.#d = t
                            }
                        } else s = v.data;
                        if (void 0 !== e.placeholderData && void 0 === s && "pending" === g) {
                            let t;
                            if (a ? .isPlaceholderData && e.placeholderData === l ? .placeholderData) t = a.data;
                            else if (t = "function" == typeof e.placeholderData ? e.placeholderData(this.#S ? .state.data, this.#S) : e.placeholderData, e.select && void 0 !== t) try {
                                t = e.select(t), this.#d = null
                            } catch (t) {
                                this.#d = t
                            }
                            void 0 !== t && (g = "success", s = (0, o.pl)(a ? .data, t, e), b = !0)
                        }
                        this.#d && (m = this.#d, s = this.#g, R = Date.now(), g = "error");
                        let S = "fetching" === v.fetchStatus,
                            O = "pending" === g,
                            Q = "error" === g,
                            C = O && S,
                            E = void 0 !== s,
                            w = {
                                status: g,
                                fetchStatus: v.fetchStatus,
                                isPending: O,
                                isSuccess: "success" === g,
                                isError: Q,
                                isInitialLoading: C,
                                isLoading: C,
                                data: s,
                                dataUpdatedAt: v.dataUpdatedAt,
                                error: m,
                                errorUpdatedAt: R,
                                failureCount: v.fetchFailureCount,
                                failureReason: v.fetchFailureReason,
                                errorUpdateCount: v.errorUpdateCount,
                                isFetched: v.dataUpdateCount > 0 || v.errorUpdateCount > 0,
                                isFetchedAfterMount: v.dataUpdateCount > p.dataUpdateCount || v.errorUpdateCount > p.errorUpdateCount,
                                isFetching: S,
                                isRefetching: S && !O,
                                isLoadingError: Q && !E,
                                isPaused: "paused" === v.fetchStatus,
                                isPlaceholderData: b,
                                isRefetchError: Q && E,
                                isStale: f(t, e),
                                refetch: this.refetch,
                                promise: this.#f
                            };
                        if (this.options.experimental_prefetchInRender) {
                            let e = t => {
                                    "error" === w.status ? t.reject(w.error) : void 0 !== w.data && t.resolve(w.data)
                                },
                                s = () => {
                                    e(this.#f = w.promise = (0, u.T)())
                                },
                                i = this.#f;
                            switch (i.status) {
                                case "pending":
                                    t.queryHash === r.queryHash && e(i);
                                    break;
                                case "fulfilled":
                                    ("error" === w.status || w.data !== i.value) && s();
                                    break;
                                case "rejected":
                                    ("error" !== w.status || w.error !== i.reason) && s()
                            }
                        }
                        return w
                    }
                    updateResult() {
                        let t = this.#v,
                            e = this.createResult(this.#p, this.options);
                        this.#b = this.#p.state, this.#m = this.options, void 0 !== this.#b.data && (this.#S = this.#p), (0, o.f8)(e, t) || (this.#v = e, this.#q({
                            listeners: (() => {
                                if (!t) return !0;
                                let {
                                    notifyOnChangeProps: e
                                } = this.options, s = "function" == typeof e ? e() : e;
                                if ("all" === s || !s && !this.#E.size) return !0;
                                let r = new Set(s ? ? this.#E);
                                return this.options.throwOnError && r.add("error"), Object.keys(this.#v).some(e => this.#v[e] !== t[e] && r.has(e))
                            })()
                        }))
                    }#
                    j() {
                        let t = this.#u.getQueryCache().build(this.#u, this.options);
                        if (t === this.#p) return;
                        let e = this.#p;
                        this.#p = t, this.#y = t.state, this.hasListeners() && (e ? .removeObserver(this), t.addObserver(this))
                    }
                    onQueryUpdate() {
                        this.updateResult(), this.hasListeners() && this.#T()
                    }#
                    q(t) {
                        i.jG.batch(() => {
                            t.listeners && this.listeners.forEach(t => {
                                t(this.#v)
                            }), this.#u.getQueryCache().notify({
                                query: this.#p,
                                type: "observerResultsUpdated"
                            })
                        })
                    }
                };

            function c(t, e) {
                return !1 !== (0, o.Eh)(e.enabled, t) && void 0 === t.state.data && !("error" === t.state.status && !1 === e.retryOnMount) || void 0 !== t.state.data && l(t, e, e.refetchOnMount)
            }

            function l(t, e, s) {
                if (!1 !== (0, o.Eh)(e.enabled, t)) {
                    let r = "function" == typeof s ? s(t) : s;
                    return "always" === r || !1 !== r && f(t, e)
                }
                return !1
            }

            function d(t, e, s, r) {
                return (t !== e || !1 === (0, o.Eh)(r.enabled, t)) && (!s.suspense || "error" !== t.state.status) && f(t, s)
            }

            function f(t, e) {
                return !1 !== (0, o.Eh)(e.enabled, t) && t.isStaleByTime((0, o.d2)(e.staleTime, t))
            }
        },
        2955: (t, e, s) => {
            s.d(e, {
                k: () => i
            });
            var r = s(84403),
                i = class {#
                    P;
                    destroy() {
                        this.clearGcTimeout()
                    }
                    scheduleGc() {
                        this.clearGcTimeout(), (0, r.gn)(this.gcTime) && (this.#P = setTimeout(() => {
                            this.optionalRemove()
                        }, this.gcTime))
                    }
                    updateGcTime(t) {
                        this.gcTime = Math.max(this.gcTime || 0, t ? ? (r.S$ ? 1 / 0 : 3e5))
                    }
                    clearGcTimeout() {
                        this.#P && (clearTimeout(this.#P), this.#P = void 0)
                    }
                }
        },
        14267: (t, e, s) => {
            s.d(e, {
                II: () => l,
                v_: () => o,
                wm: () => c
            });
            var r = s(34017),
                i = s(38248),
                n = s(41277),
                a = s(84403);

            function u(t) {
                return Math.min(1e3 * 2 ** t, 3e4)
            }

            function o(t) {
                return (t ? ? "online") !== "online" || i.t.isOnline()
            }
            var h = class extends Error {
                constructor(t) {
                    super("CancelledError"), this.revert = t ? .revert, this.silent = t ? .silent
                }
            };

            function c(t) {
                return t instanceof h
            }

            function l(t) {
                let e, s = !1,
                    c = 0,
                    l = !1,
                    d = (0, n.T)(),
                    f = () => r.m.isFocused() && ("always" === t.networkMode || i.t.isOnline()) && t.canRun(),
                    p = () => o(t.networkMode) && t.canRun(),
                    y = s => {
                        l || (l = !0, t.onSuccess ? .(s), e ? .(), d.resolve(s))
                    },
                    v = s => {
                        l || (l = !0, t.onError ? .(s), e ? .(), d.reject(s))
                    },
                    b = () => new Promise(s => {
                        e = t => {
                            (l || f()) && s(t)
                        }, t.onPause ? .()
                    }).then(() => {
                        e = void 0, l || t.onContinue ? .()
                    }),
                    m = () => {
                        let e;
                        if (l) return;
                        let r = 0 === c ? t.initialPromise : void 0;
                        try {
                            e = r ? ? t.fn()
                        } catch (t) {
                            e = Promise.reject(t)
                        }
                        Promise.resolve(e).then(y).catch(e => {
                            if (l) return;
                            let r = t.retry ? ? (a.S$ ? 0 : 3),
                                i = t.retryDelay ? ? u,
                                n = "function" == typeof i ? i(c, e) : i,
                                o = !0 === r || "number" == typeof r && c < r || "function" == typeof r && r(c, e);
                            if (s || !o) {
                                v(e);
                                return
                            }
                            c++, t.onFail ? .(c, e), (0, a.yy)(n).then(() => f() ? void 0 : b()).then(() => {
                                s ? v(e) : m()
                            })
                        })
                    };
                return {
                    promise: d,
                    cancel: e => {
                        l || (v(new h(e)), t.abort ? .())
                    },
                    continue: () => (e ? .(), d),
                    cancelRetry: () => {
                        s = !0
                    },
                    continueRetry: () => {
                        s = !1
                    },
                    canStart: p,
                    start: () => (p() ? m() : b().then(m), d)
                }
            }
        },
        99323: (t, e, s) => {
            s.d(e, {
                Q: () => r
            });
            var r = class {
                constructor() {
                    this.listeners = new Set, this.subscribe = this.subscribe.bind(this)
                }
                subscribe(t) {
                    return this.listeners.add(t), this.onSubscribe(), () => {
                        this.listeners.delete(t), this.onUnsubscribe()
                    }
                }
                hasListeners() {
                    return this.listeners.size > 0
                }
                onSubscribe() {}
                onUnsubscribe() {}
            }
        },
        41277: (t, e, s) => {
            s.d(e, {
                T: () => r
            });

            function r() {
                let t, e;
                let s = new Promise((s, r) => {
                    t = s, e = r
                });

                function r(t) {
                    Object.assign(s, t), delete s.resolve, delete s.reject
                }
                return s.status = "pending", s.catch(() => {}), s.resolve = e => {
                    r({
                        status: "fulfilled",
                        value: e
                    }), t(e)
                }, s.reject = t => {
                    r({
                        status: "rejected",
                        reason: t
                    }), e(t)
                }, s
            }
        },
        84403: (t, e, s) => {
            s.d(e, {
                Cp: () => p,
                EN: () => f,
                Eh: () => h,
                F$: () => d,
                MK: () => c,
                S$: () => r,
                ZM: () => C,
                ZZ: () => O,
                Zw: () => n,
                d2: () => o,
                f8: () => y,
                gn: () => a,
                hT: () => Q,
                j3: () => u,
                lQ: () => i,
                nJ: () => l,
                pl: () => g,
                y9: () => S,
                yy: () => R
            });
            var r = "undefined" == typeof window || "Deno" in globalThis;

            function i() {}

            function n(t, e) {
                return "function" == typeof t ? t(e) : t
            }

            function a(t) {
                return "number" == typeof t && t >= 0 && t !== 1 / 0
            }

            function u(t, e) {
                return Math.max(t + (e || 0) - Date.now(), 0)
            }

            function o(t, e) {
                return "function" == typeof t ? t(e) : t
            }

            function h(t, e) {
                return "function" == typeof t ? t(e) : t
            }

            function c(t, e) {
                let {
                    type: s = "all",
                    exact: r,
                    fetchStatus: i,
                    predicate: n,
                    queryKey: a,
                    stale: u
                } = t;
                if (a) {
                    if (r) {
                        if (e.queryHash !== d(a, e.options)) return !1
                    } else if (!p(e.queryKey, a)) return !1
                }
                if ("all" !== s) {
                    let t = e.isActive();
                    if ("active" === s && !t || "inactive" === s && t) return !1
                }
                return ("boolean" != typeof u || e.isStale() === u) && (!i || i === e.state.fetchStatus) && (!n || !!n(e))
            }

            function l(t, e) {
                let {
                    exact: s,
                    status: r,
                    predicate: i,
                    mutationKey: n
                } = t;
                if (n) {
                    if (!e.options.mutationKey) return !1;
                    if (s) {
                        if (f(e.options.mutationKey) !== f(n)) return !1
                    } else if (!p(e.options.mutationKey, n)) return !1
                }
                return (!r || e.state.status === r) && (!i || !!i(e))
            }

            function d(t, e) {
                return (e ? .queryKeyHashFn || f)(t)
            }

            function f(t) {
                return JSON.stringify(t, (t, e) => b(e) ? Object.keys(e).sort().reduce((t, s) => (t[s] = e[s], t), {}) : e)
            }

            function p(t, e) {
                return t === e || typeof t == typeof e && !!t && !!e && "object" == typeof t && "object" == typeof e && Object.keys(e).every(s => p(t[s], e[s]))
            }

            function y(t, e) {
                if (!e || Object.keys(t).length !== Object.keys(e).length) return !1;
                for (let s in t)
                    if (t[s] !== e[s]) return !1;
                return !0
            }

            function v(t) {
                return Array.isArray(t) && t.length === Object.keys(t).length
            }

            function b(t) {
                if (!m(t)) return !1;
                let e = t.constructor;
                if (void 0 === e) return !0;
                let s = e.prototype;
                return !!(m(s) && s.hasOwnProperty("isPrototypeOf")) && Object.getPrototypeOf(t) === Object.prototype
            }

            function m(t) {
                return "[object Object]" === Object.prototype.toString.call(t)
            }

            function R(t) {
                return new Promise(e => {
                    setTimeout(e, t)
                })
            }

            function g(t, e, s) {
                return "function" == typeof s.structuralSharing ? s.structuralSharing(t, e) : !1 !== s.structuralSharing ? function t(e, s) {
                    if (e === s) return e;
                    let r = v(e) && v(s);
                    if (r || b(e) && b(s)) {
                        let i = r ? e : Object.keys(e),
                            n = i.length,
                            a = r ? s : Object.keys(s),
                            u = a.length,
                            o = r ? [] : {},
                            h = 0;
                        for (let n = 0; n < u; n++) {
                            let u = r ? n : a[n];
                            (!r && i.includes(u) || r) && void 0 === e[u] && void 0 === s[u] ? (o[u] = void 0, h++) : (o[u] = t(e[u], s[u]), o[u] === e[u] && void 0 !== e[u] && h++)
                        }
                        return n === u && h === n ? e : o
                    }
                    return s
                }(t, e) : e
            }

            function S(t, e, s = 0) {
                let r = [...t, e];
                return s && r.length > s ? r.slice(1) : r
            }

            function O(t, e, s = 0) {
                let r = [e, ...t];
                return s && r.length > s ? r.slice(0, -1) : r
            }
            var Q = Symbol();

            function C(t, e) {
                return !t.queryFn && e ? .initialPromise ? () => e.initialPromise : t.queryFn && t.queryFn !== Q ? t.queryFn : () => Promise.reject(Error(`Missing queryFn: '${t.queryHash}'`))
            }
        },
        35906: (t, e, s) => {
            s.d(e, {
                Ht: () => u,
                jE: () => a
            });
            var r = s(12115),
                i = s(95155),
                n = r.createContext(void 0),
                a = t => {
                    let e = r.useContext(n);
                    if (t) return t;
                    if (!e) throw Error("No QueryClient set, use QueryClientProvider to set one");
                    return e
                },
                u = t => {
                    let {
                        client: e,
                        children: s
                    } = t;
                    return r.useEffect(() => (e.mount(), () => {
                        e.unmount()
                    }), [e]), (0, i.jsx)(n.Provider, {
                        value: e,
                        children: s
                    })
                }
        },
        13237: (t, e, s) => {
            s.d(e, {
                t: () => R
            });
            var r = s(12115),
                i = s(15586),
                n = s(84403),
                a = s(35906);
            s(95155);
            var u = r.createContext(function() {
                    let t = !1;
                    return {
                        clearReset: () => {
                            t = !1
                        },
                        reset: () => {
                            t = !0
                        },
                        isReset: () => t
                    }
                }()),
                o = () => r.useContext(u),
                h = s(96373),
                c = (t, e) => {
                    (t.suspense || t.throwOnError || t.experimental_prefetchInRender) && !e.isReset() && (t.retryOnMount = !1)
                },
                l = t => {
                    r.useEffect(() => {
                        t.clearReset()
                    }, [t])
                },
                d = t => {
                    let {
                        result: e,
                        errorResetBoundary: s,
                        throwOnError: r,
                        query: i,
                        suspense: n
                    } = t;
                    return e.isError && !s.isReset() && !e.isFetching && i && (n && void 0 === e.data || (0, h.G)(r, [e.error, i]))
                },
                f = r.createContext(!1),
                p = () => r.useContext(f);
            f.Provider;
            var y = t => {
                    let e = t.staleTime;
                    t.suspense && (t.staleTime = "function" == typeof e ? (...t) => Math.max(e(...t), 1e3) : Math.max(e ? ? 1e3, 1e3), "number" == typeof t.gcTime && (t.gcTime = Math.max(t.gcTime, 1e3)))
                },
                v = (t, e) => t.isLoading && t.isFetching && !e,
                b = (t, e) => t ? .suspense && e.isPending,
                m = (t, e, s) => e.fetchOptimistic(t).catch(() => {
                    s.clearReset()
                });

            function R(t, e, s) {
                var u, f, R, g, S;
                let O = (0, a.jE)(s),
                    Q = p(),
                    C = o(),
                    E = O.defaultQueryOptions(t);
                null === (f = O.getDefaultOptions().queries) || void 0 === f || null === (u = f._experimental_beforeQuery) || void 0 === u || u.call(f, E), E._optimisticResults = Q ? "isRestoring" : "optimistic", y(E), c(E, C), l(C);
                let w = !O.getQueryCache().get(E.queryHash),
                    [T] = r.useState(() => new e(O, E)),
                    F = T.getOptimisticResult(E),
                    I = !Q && !1 !== t.subscribed;
                if (r.useSyncExternalStore(r.useCallback(t => {
                        let e = I ? T.subscribe(i.jG.batchCalls(t)) : h.l;
                        return T.updateResult(), e
                    }, [T, I]), () => T.getCurrentResult(), () => T.getCurrentResult()), r.useEffect(() => {
                        T.setOptions(E)
                    }, [E, T]), b(E, F)) throw m(E, T, C);
                if (d({
                        result: F,
                        errorResetBoundary: C,
                        throwOnError: E.throwOnError,
                        query: O.getQueryCache().get(E.queryHash),
                        suspense: E.suspense
                    })) throw F.error;
                if (null === (g = O.getDefaultOptions().queries) || void 0 === g || null === (R = g._experimental_afterQuery) || void 0 === R || R.call(g, E, F), E.experimental_prefetchInRender && !n.S$ && v(F, Q)) {
                    let t = w ? m(E, T, C) : null === (S = O.getQueryCache().get(E.queryHash)) || void 0 === S ? void 0 : S.promise;
                    null == t || t.catch(h.l).finally(() => {
                        T.updateResult()
                    })
                }
                return E.notifyOnChangeProps ? F : T.trackResult(F)
            }
        },
        96373: (t, e, s) => {
            function r(t, e) {
                return "function" == typeof t ? t(...e) : !!t
            }

            function i() {}
            s.d(e, {
                G: () => r,
                l: () => i
            })
        }
    }
]);