"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2202], {
        22885: (a, t, l) => {
            l.d(t, {
                YZI: () => e,
                oss: () => c
            });
            var r = l(93435);

            function c(a) {
                return (0, r.k5)({
                    tag: "svg",
                    attr: {
                        viewBox: "0 0 24 24"
                    },
                    child: [{
                        tag: "path",
                        attr: {
                            d: "M5.22 8.22a.749.749 0 0 0 0 1.06l6.25 6.25a.749.749 0 0 0 1.06 0l6.25-6.25a.749.749 0 1 0-1.06-1.06L12 13.939 6.28 8.22a.749.749 0 0 0-1.06 0Z"
                        },
                        child: []
                    }]
                })(a)
            }

            function e(a) {
                return (0, r.k5)({
                    tag: "svg",
                    attr: {
                        viewBox: "0 0 24 24"
                    },
                    child: [{
                        tag: "path",
                        attr: {
                            d: "M8.72 18.78a.75.75 0 0 1 0-1.06L14.44 12 8.72 6.28a.751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018l6.25 6.25a.75.75 0 0 1 0 1.06l-6.25 6.25a.75.75 0 0 1-1.06 0Z"
                        },
                        child: []
                    }]
                })(a)
            }
        }
    }
]);