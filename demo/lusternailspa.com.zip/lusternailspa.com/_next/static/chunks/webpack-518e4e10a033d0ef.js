(() => {
    "use strict";
    var e = {},
        t = {};

    function r(o) {
        var n = t[o];
        if (void 0 !== n) return n.exports;
        var a = t[o] = {
                id: o,
                loaded: !1,
                exports: {}
            },
            i = !0;
        try {
            e[o].call(a.exports, a, a.exports, r), i = !1
        } finally {
            i && delete t[o]
        }
        return a.loaded = !0, a.exports
    }
    r.m = e, r.amdO = {}, (() => {
        var e = [];
        r.O = (t, o, n, a) => {
            if (o) {
                a = a || 0;
                for (var i = e.length; i > 0 && e[i - 1][2] > a; i--) e[i] = e[i - 1];
                e[i] = [o, n, a];
                return
            }
            for (var u = 1 / 0, i = 0; i < e.length; i++) {
                for (var [o, n, a] = e[i], l = !0, d = 0; d < o.length; d++)(!1 & a || u >= a) && Object.keys(r.O).every(e => r.O[e](o[d])) ? o.splice(d--, 1) : (l = !1, a < u && (u = a));
                if (l) {
                    e.splice(i--, 1);
                    var c = n();
                    void 0 !== c && (t = c)
                }
            }
            return t
        }
    })(), r.n = e => {
        var t = e && e.__esModule ? () => e.default : () => e;
        return r.d(t, {
            a: t
        }), t
    }, (() => {
        var e, t = Object.getPrototypeOf ? e => Object.getPrototypeOf(e) : e => e.__proto__;
        r.t = function(o, n) {
            if (1 & n && (o = this(o)), 8 & n || "object" == typeof o && o && (4 & n && o.__esModule || 16 & n && "function" == typeof o.then)) return o;
            var a = Object.create(null);
            r.r(a);
            var i = {};
            e = e || [null, t({}), t([]), t(t)];
            for (var u = 2 & n && o;
                "object" == typeof u && !~e.indexOf(u); u = t(u)) Object.getOwnPropertyNames(u).forEach(e => i[e] = () => o[e]);
            return i.default = () => o, r.d(a, i), a
        }
    })(), r.d = (e, t) => {
        for (var o in t) r.o(t, o) && !r.o(e, o) && Object.defineProperty(e, o, {
            enumerable: !0,
            get: t[o]
        })
    }, r.f = {}, r.e = e => Promise.all(Object.keys(r.f).reduce((t, o) => (r.f[o](e, t), t), [])), r.u = e => 4711 === e ? "static/chunks/4711.332ed5c143a41510.js" : "static/chunks/" + (3842 === e ? "06ed8259" : e) + "-" + ({
        3842: "f54e2700069f7f64",
        5997: "22ff27c93feec004"
    })[e] + ".js", r.miniCssF = e => {}, r.g = function() {
        if ("object" == typeof globalThis) return globalThis;
        try {
            return this || Function("return this")()
        } catch (e) {
            if ("object" == typeof window) return window
        }
    }(), r.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t), (() => {
        var e = {},
            t = "_N_E:";
        r.l = (o, n, a, i) => {
            if (e[o]) {
                e[o].push(n);
                return
            }
            if (void 0 !== a)
                for (var u, l, d = document.getElementsByTagName("script"), c = 0; c < d.length; c++) {
                    var s = d[c];
                    if (s.getAttribute("src") == o || s.getAttribute("data-webpack") == t + a) {
                        u = s;
                        break
                    }
                }
            u || (l = !0, (u = document.createElement("script")).charset = "utf-8", u.timeout = 120, r.nc && u.setAttribute("nonce", r.nc), u.setAttribute("data-webpack", t + a), u.src = r.tu(o)), e[o] = [n];
            var f = (t, r) => {
                    u.onerror = u.onload = null, clearTimeout(p);
                    var n = e[o];
                    if (delete e[o], u.parentNode && u.parentNode.removeChild(u), n && n.forEach(e => e(r)), t) return t(r)
                },
                p = setTimeout(f.bind(null, void 0, {
                    type: "timeout",
                    target: u
                }), 12e4);
            u.onerror = f.bind(null, u.onerror), u.onload = f.bind(null, u.onload), l && document.head.appendChild(u)
        }
    })(), r.r = e => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, r.nmd = e => (e.paths = [], e.children || (e.children = []), e), (() => {
        var e;
        r.tt = () => (void 0 === e && (e = {
            createScriptURL: e => e
        }, "undefined" != typeof trustedTypes && trustedTypes.createPolicy && (e = trustedTypes.createPolicy("nextjs#bundler", e))), e)
    })(), r.tu = e => r.tt().createScriptURL(e), r.p = "/_next/", (() => {
        var e = {
            8068: 0,
            3603: 0,
            4523: 0,
            5792: 0,
            8850: 0,
            7462: 0,
            4797: 0
        };
        r.f.j = (t, o) => {
            var n = r.o(e, t) ? e[t] : void 0;
            if (0 !== n) {
                if (n) o.push(n[2]);
                else if (/^(3603|4523|4797|5792|7462|8068|8850)$/.test(t)) e[t] = 0;
                else {
                    var a = new Promise((r, o) => n = e[t] = [r, o]);
                    o.push(n[2] = a);
                    var i = r.p + r.u(t),
                        u = Error();
                    r.l(i, o => {
                        if (r.o(e, t) && (0 !== (n = e[t]) && (e[t] = void 0), n)) {
                            var a = o && ("load" === o.type ? "missing" : o.type),
                                i = o && o.target && o.target.src;
                            u.message = "Loading chunk " + t + " failed.\n(" + a + ": " + i + ")", u.name = "ChunkLoadError", u.type = a, u.request = i, n[1](u)
                        }
                    }, "chunk-" + t, t)
                }
            }
        }, r.O.j = t => 0 === e[t];
        var t = (t, o) => {
                var n, a, [i, u, l] = o,
                    d = 0;
                if (i.some(t => 0 !== e[t])) {
                    for (n in u) r.o(u, n) && (r.m[n] = u[n]);
                    if (l) var c = l(r)
                }
                for (t && t(o); d < i.length; d++) a = i[d], r.o(e, a) && e[a] && e[a][0](), e[a] = 0;
                return r.O(c)
            },
            o = self.webpackChunk_N_E = self.webpackChunk_N_E || [];
        o.forEach(t.bind(null, 0)), o.push = t.bind(null, o.push.bind(o))
    })()
})();